<?php

return [
    'stripe' => [
        'secret' => env('STRIPE_SECRET'),
    ],

    'ticket_tailor' => [
        'api_key' => env('TICKET_TAILOR_API_KEY'),
        'base_url' => env('TICKET_TAILOR_BASE_URL', 'https://api.tickettailor.com/v1'),
    ],
];
