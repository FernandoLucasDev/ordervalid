<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    protected $fillable = [
        'name',
        'email',
        'event_platform',
        'payment_processor',
        'notes',
        'source',
    ];
}
