<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

// Named CaseModel because `Case` collides with the PHP reserved word — the
// table is still `cases`, and this is what shows up in Filament as "Cases".
class CaseModel extends Model
{
    use HasFactory;

    protected $table = 'cases';

    protected $fillable = [
        'reference',
        'event_name',
        'customer_name',
        'customer_email',
        'ticket_tailor_order_id',
        'stripe_charge_id',
        'stripe_dispute_id',
        'dispute_reason',
        'amount_cents',
        'currency',
        'response_deadline',
        'status',
        'is_compatible',
        'missing_info',
    ];

    protected function casts(): array
    {
        return [
            'response_deadline' => 'date',
            'is_compatible' => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (CaseModel $case) {
            if (! $case->reference) {
                $case->reference = 'OV-'.str_pad((string) (static::max('id') + 1), 4, '0', STR_PAD_LEFT);
            }
        });
    }

    public function evidenceDocuments(): HasMany
    {
        return $this->hasMany(EvidenceDocument::class, 'case_id');
    }

    public function getAmountFormattedAttribute(): string
    {
        return number_format($this->amount_cents / 100, 2).' '.Str::upper($this->currency);
    }
}
