<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class LandingController extends Controller
{
    public function show()
    {
        return view('landing.index');
    }

    public function apply(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['nullable', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'event_platform' => ['nullable', 'string', 'max:255'],
            'payment_processor' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        Lead::create($data + ['source' => 'landing_page']);

        return back()->with('applied', true);
    }
}
