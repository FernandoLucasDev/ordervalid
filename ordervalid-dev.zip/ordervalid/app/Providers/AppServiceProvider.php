<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(\App\Services\TicketTailorClient::class);
        $this->app->singleton(\App\Services\StripeClient::class);
    }

    public function boot(): void
    {
        //
    }
}
