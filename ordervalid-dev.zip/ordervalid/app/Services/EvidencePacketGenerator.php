<?php

namespace App\Services;

use App\Models\CaseModel;
use App\Models\EvidenceDocument;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Storage;

/**
 * Orchestrates one case: pulls Ticket Tailor + Stripe data, decides whether
 * there's enough to build a packet, and generates the evidence documents
 * shown on the "Evidence Review" screen.
 */
class EvidencePacketGenerator
{
    public function __construct(
        protected TicketTailorClient $ticketTailor,
        protected StripeClient $stripe,
    ) {}

    public function generate(CaseModel $case): CaseModel
    {
        $case->update(['status' => 'checking']);

        $order = $case->ticket_tailor_order_id
            ? $this->ticketTailor->getOrder($case->ticket_tailor_order_id)
            : null;

        $charge = $case->stripe_charge_id
            ? $this->stripe->getCharge($case->stripe_charge_id)
            : null;

        $missing = $this->missingInfo($case, $order, $charge);

        if (filled($missing)) {
            $case->update([
                'status' => 'incompatible',
                'is_compatible' => false,
                'missing_info' => implode("\n", $missing),
            ]);

            $this->storeEvidence($case, 'missing_information_list', textContent: implode("\n", $missing));

            return $case->fresh();
        }

        $case->update(['is_compatible' => true, 'missing_info' => null]);

        $this->storeEvidence($case, 'case_summary_pdf', filePath: $this->renderPdf($case, $order, $charge, 'pdf.case-summary', 'case-summary'));
        $this->storeEvidence($case, 'attendance_evidence_pdf', filePath: $this->renderPdf($case, $order, $charge, 'pdf.attendance-evidence', 'attendance-evidence'));
        $this->storeEvidence($case, 'draft_response_text', textContent: $this->draftResponseText($case, $order, $charge));

        $case->update(['status' => 'ready_to_review']);

        return $case->fresh('evidenceDocuments');
    }

    /** @return array<int, string> */
    protected function missingInfo(CaseModel $case, ?array $order, ?array $charge): array
    {
        $missing = [];

        if (! $order) {
            $missing[] = 'No matching Ticket Tailor order found for ID "'.$case->ticket_tailor_order_id.'".';
        } elseif (empty($order['check_ins'])) {
            $missing[] = 'Order found, but no check-in record — without proof of attendance this packet is weaker.';
        }

        if (! $charge) {
            $missing[] = 'No matching Stripe charge found for ID "'.$case->stripe_charge_id.'".';
        }

        return $missing;
    }

    protected function renderPdf(CaseModel $case, ?array $order, ?array $charge, string $view, string $slug): string
    {
        $pdf = Pdf::loadView($view, compact('case', 'order', 'charge'));

        $path = "evidence/{$case->reference}/{$slug}.pdf";
        Storage::disk('public')->put($path, $pdf->output());

        return $path;
    }

    protected function draftResponseText(CaseModel $case, ?array $order, ?array $charge): string
    {
        $checkIns = $order['check_ins'] ?? [];
        $attendeeNames = collect($checkIns)->pluck('holder_name')->implode(', ');

        return <<<TEXT
        This charge corresponds to order {$case->ticket_tailor_order_id} for "{$case->event_name}".

        The buyer ({$case->customer_name}, {$case->customer_email}) purchased valid tickets through our
        event ticketing platform (Ticket Tailor) and the order was fulfilled electronically with a
        confirmation sent to the buyer's email on file.

        Attendance was verified at the door via check-in scan for: {$attendeeNames}.

        This order was legitimate, the goods/services (event entry) were delivered, and the dispute
        reason "{$case->dispute_reason}" is not supported by our records. Supporting documentation
        (order confirmation and check-in log) is attached.

        Paste this into the relevant field of your Stripe dispute response, and adjust names/tone
        before submitting.
        TEXT;
    }

    protected function storeEvidence(CaseModel $case, string $type, ?string $filePath = null, ?string $textContent = null): EvidenceDocument
    {
        return EvidenceDocument::updateOrCreate(
            ['case_id' => $case->id, 'type' => $type],
            ['file_path' => $filePath, 'text_content' => $textContent, 'generated_at' => now()]
        );
    }
}
