<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Stripe\StripeClient as StripeSdk;

/**
 * Thin wrapper around stripe-php. Falls back to mock data in dev when
 * STRIPE_SECRET is empty, same pattern as TicketTailorClient.
 */
class StripeClient
{
    protected ?StripeSdk $sdk = null;

    public function __construct(protected ?string $secret = null)
    {
        $this->secret ??= config('services.stripe.secret');

        if (filled($this->secret)) {
            $this->sdk = new StripeSdk($this->secret);
        }
    }

    public function isConfigured(): bool
    {
        return $this->sdk !== null;
    }

    /**
     * @return array{id: string, amount: int, currency: string, dispute_reason: ?string, dispute_deadline: ?string}|null
     */
    public function getCharge(string $chargeId): ?array
    {
        if (! $this->isConfigured()) {
            return $this->mockCharge($chargeId);
        }

        try {
            $charge = $this->sdk->charges->retrieve($chargeId, ['expand' => ['dispute']]);

            return [
                'id' => $charge->id,
                'amount' => $charge->amount,
                'currency' => $charge->currency,
                'dispute_reason' => $charge->dispute->reason ?? null,
                'dispute_deadline' => isset($charge->dispute->evidence_details->due_by)
                    ? date('Y-m-d', $charge->dispute->evidence_details->due_by)
                    : null,
            ];
        } catch (\Throwable $e) {
            Log::error('Stripe charge lookup errored', ['charge_id' => $chargeId, 'message' => $e->getMessage()]);

            return null;
        }
    }

    protected function mockCharge(string $chargeId): array
    {
        return [
            'id' => $chargeId ?: 'ch_mock_0001',
            'amount' => 4500,
            'currency' => 'usd',
            'dispute_reason' => 'product_not_received',
            'dispute_deadline' => now()->addDays(6)->toDateString(),
        ];
    }
}
