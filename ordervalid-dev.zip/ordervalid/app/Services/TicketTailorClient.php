<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Thin wrapper around the Ticket Tailor REST API (https://developers.tickettailor.com).
 *
 * In dev, when TICKET_TAILOR_API_KEY is empty, every call returns realistic
 * mock data instead of hitting the network — so the app is fully clickable
 * without real credentials. Fill in the key in .env to go live.
 */
class TicketTailorClient
{
    public function __construct(
        protected ?string $apiKey = null,
        protected ?string $baseUrl = null,
    ) {
        $this->apiKey ??= config('services.ticket_tailor.api_key');
        $this->baseUrl ??= config('services.ticket_tailor.base_url');
    }

    public function isConfigured(): bool
    {
        return filled($this->apiKey);
    }

    /**
     * @return array{
     *   id: string, event_name: string, buyer_name: string, buyer_email: string,
     *   total: int, currency: string, line_items: array, check_ins: array
     * }|null
     */
    public function getOrder(string $orderId): ?array
    {
        if (! $this->isConfigured()) {
            return $this->mockOrder($orderId);
        }

        try {
            $response = Http::withBasicAuth($this->apiKey, '')
                ->get("{$this->baseUrl}/orders/{$orderId}");

            if ($response->failed()) {
                Log::warning('Ticket Tailor order lookup failed', ['order_id' => $orderId, 'status' => $response->status()]);

                return null;
            }

            return $response->json();
        } catch (\Throwable $e) {
            Log::error('Ticket Tailor order lookup errored', ['order_id' => $orderId, 'message' => $e->getMessage()]);

            return null;
        }
    }

    /**
     * @return array<int, array{ticket_id: string, holder_name: string, checked_in_at: ?string}>
     */
    public function getCheckIns(string $orderId): array
    {
        if (! $this->isConfigured()) {
            return $this->mockCheckIns();
        }

        try {
            $response = Http::withBasicAuth($this->apiKey, '')
                ->get("{$this->baseUrl}/check_ins", ['order_id' => $orderId]);

            return $response->successful() ? ($response->json('data') ?? []) : [];
        } catch (\Throwable $e) {
            Log::error('Ticket Tailor check-in lookup errored', ['order_id' => $orderId, 'message' => $e->getMessage()]);

            return [];
        }
    }

    protected function mockOrder(string $orderId): array
    {
        return [
            'id' => $orderId ?: 'TT-MOCK-0001',
            'event_name' => 'Indie Night — Sep 12',
            'buyer_name' => 'Jamie Rivera',
            'buyer_email' => 'jamie.rivera@example.com',
            'total' => 4500,
            'currency' => 'usd',
            'line_items' => [
                ['description' => 'General Admission x2', 'amount' => 4000],
                ['description' => 'Booking fee', 'amount' => 500],
            ],
            'check_ins' => $this->mockCheckIns(),
        ];
    }

    protected function mockCheckIns(): array
    {
        return [
            ['ticket_id' => 'TKT-1001', 'holder_name' => 'Jamie Rivera', 'checked_in_at' => now()->subDays(3)->toIso8601String()],
            ['ticket_id' => 'TKT-1002', 'holder_name' => 'Alex Rivera', 'checked_in_at' => now()->subDays(3)->addMinutes(4)->toIso8601String()],
        ];
    }
}
