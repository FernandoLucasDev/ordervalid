<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CaseResource\Pages;
use App\Jobs\GenerateEvidencePacket;
use App\Models\CaseModel;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Infolists\Components\Section as InfolistSection;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Tables\Actions\Action;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class CaseResource extends Resource
{
    protected static ?string $model = CaseModel::class;

    protected static ?string $navigationIcon = 'heroicon-o-shield-check';

    protected static ?string $navigationLabel = 'Cases';

    protected static ?string $modelLabel = 'case';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make('Order lookup')
                ->description('Pull the order straight from Ticket Tailor + Stripe by ID.')
                ->schema([
                    TextInput::make('event_name')->required()->maxLength(255),
                    TextInput::make('customer_name')->maxLength(255),
                    TextInput::make('customer_email')->email()->maxLength(255),
                    TextInput::make('ticket_tailor_order_id')
                        ->label('Ticket Tailor order ID')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('stripe_charge_id')
                        ->label('Stripe charge ID')
                        ->required()
                        ->maxLength(255),
                ])->columns(2),

            Section::make('Dispute')
                ->schema([
                    Select::make('dispute_reason')
                        ->options([
                            'fraudulent' => 'Fraudulent',
                            'product_not_received' => 'Product not received',
                            'product_unacceptable' => 'Product unacceptable',
                            'duplicate' => 'Duplicate',
                            'subscription_canceled' => 'Subscription canceled',
                            'unrecognized' => 'Unrecognized',
                            'other' => 'Other',
                        ])
                        ->required(),
                    TextInput::make('amount_cents')
                        ->label('Amount (cents)')
                        ->numeric()
                        ->required(),
                    TextInput::make('currency')->default('usd')->maxLength(3)->required(),
                    DatePicker::make('response_deadline')->required(),
                ])->columns(2),
        ]);
    }

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            InfolistSection::make('Case')
                ->schema([
                    TextEntry::make('reference'),
                    TextEntry::make('event_name'),
                    TextEntry::make('customer_name'),
                    TextEntry::make('customer_email'),
                    TextEntry::make('dispute_reason')->badge(),
                    TextEntry::make('amount_formatted')->label('Amount'),
                    TextEntry::make('response_deadline')->date(),
                    TextEntry::make('status')->badge(),
                ])->columns(3),

            InfolistSection::make('Missing information')
                ->icon('heroicon-o-exclamation-triangle')
                ->visible(fn (CaseModel $record) => filled($record->missing_info))
                ->schema([
                    TextEntry::make('missing_info')->label('')->columnSpanFull(),
                ]),

            InfolistSection::make('Evidence documents')
                ->schema([
                    TextEntry::make('evidenceDocuments')
                        ->label('')
                        ->state(fn (CaseModel $record) => $record->evidenceDocuments->isEmpty()
                            ? 'No documents generated yet — use "Generate packet" above.'
                            : $record->evidenceDocuments->map(fn ($doc) => '• '.str($doc->type)->replace('_', ' ')->title())->implode("\n"))
                        ->columnSpanFull(),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('reference')->searchable()->sortable(),
                TextColumn::make('event_name')->searchable(),
                TextColumn::make('dispute_reason')->badge(),
                TextColumn::make('amount_formatted')->label('Amount'),
                TextColumn::make('response_deadline')->date()->sortable(),
                BadgeColumn::make('status')
                    ->colors([
                        'secondary' => 'new',
                        'warning' => ['checking', 'incompatible'],
                        'success' => ['ready_to_review', 'delivered'],
                    ]),
            ])
            ->actions([
                Action::make('generate')
                    ->label('Generate packet')
                    ->icon('heroicon-o-document-text')
                    ->action(fn (CaseModel $record) => GenerateEvidencePacket::dispatch($record)),
                \Filament\Tables\Actions\ViewAction::make(),
                \Filament\Tables\Actions\EditAction::make(),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCases::route('/'),
            'create' => Pages\CreateCase::route('/create'),
            'view' => Pages\ViewCase::route('/{record}'),
            'edit' => Pages\EditCase::route('/{record}/edit'),
        ];
    }
}
