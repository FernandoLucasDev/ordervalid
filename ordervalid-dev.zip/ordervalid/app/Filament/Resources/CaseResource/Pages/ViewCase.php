<?php

namespace App\Filament\Resources\CaseResource\Pages;

use App\Filament\Resources\CaseResource;
use App\Jobs\GenerateEvidencePacket;
use App\Models\CaseModel;
use Filament\Actions\Action;
use Filament\Resources\Pages\ViewRecord;

class ViewCase extends ViewRecord
{
    protected static string $resource = CaseResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('generate')
                ->label('Generate packet')
                ->icon('heroicon-o-document-text')
                ->action(function (CaseModel $record) {
                    GenerateEvidencePacket::dispatch($record);
                })
                ->successNotificationTitle('Packet generation queued'),
        ];
    }
}
