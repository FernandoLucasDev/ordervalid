<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Dev admin login for the Filament panel — change this before going live.
        User::firstOrCreate(
            ['email' => 'fernando@ordervalid.dev'],
            ['name' => 'Fernando', 'password' => bcrypt('ordervalid-dev')]
        );
    }
}
