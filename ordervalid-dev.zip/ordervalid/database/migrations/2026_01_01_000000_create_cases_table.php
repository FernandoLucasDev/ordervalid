<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cases', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique(); // e.g. OV-0001, shown to the organizer
            $table->string('event_name');
            $table->string('customer_name')->nullable();
            $table->string('customer_email')->nullable();

            // Ticket Tailor + Stripe linkage
            $table->string('ticket_tailor_order_id')->nullable();
            $table->string('stripe_charge_id')->nullable();
            $table->string('stripe_dispute_id')->nullable();

            $table->enum('dispute_reason', [
                'fraudulent',
                'product_not_received',
                'product_unacceptable',
                'duplicate',
                'subscription_canceled',
                'unrecognized',
                'other',
            ])->default('other');

            $table->unsignedBigInteger('amount_cents');
            $table->string('currency', 3)->default('usd');
            $table->date('response_deadline')->nullable();

            $table->enum('status', [
                'new',               // just created, nothing pulled yet
                'checking',          // pulling Ticket Tailor + Stripe data
                'incompatible',      // missing data, can't build a packet
                'ready_to_review',   // packet generated, awaiting organizer review
                'delivered',         // sent to the organizer
            ])->default('new');

            $table->boolean('is_compatible')->nullable();
            $table->text('missing_info')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cases');
    }
};
