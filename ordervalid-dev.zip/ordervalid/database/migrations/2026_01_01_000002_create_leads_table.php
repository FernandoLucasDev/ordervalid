<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Captures every "Apply for the $29 pilot" submission from the landing page —
    // this is the validation signal: who clicked through from the ad and raised a hand.
    public function up(): void
    {
        Schema::create('leads', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('email');
            $table->string('event_platform')->nullable(); // e.g. "Ticket Tailor"
            $table->string('payment_processor')->nullable(); // e.g. "Stripe"
            $table->text('notes')->nullable();
            $table->string('source')->default('landing_page');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leads');
    }
};
