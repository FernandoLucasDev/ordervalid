<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('evidence_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('case_id')->constrained('cases')->cascadeOnDelete();

            $table->enum('type', [
                'case_summary_pdf',
                'attendance_evidence_pdf',
                'draft_response_text',
                'missing_information_list',
            ]);

            $table->string('file_path')->nullable();
            $table->longText('text_content')->nullable(); // for draft_response_text
            $table->timestamp('generated_at')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('evidence_documents');
    }
};
