#!/bin/sh
set -e

cd /var/www/html

# Wait for the database to accept connections (simple retry loop, no extra deps).
echo "Waiting for database..."
until php -r "new PDO('mysql:host='.getenv('DB_HOST').';port='.getenv('DB_PORT'), getenv('DB_USERNAME'), getenv('DB_PASSWORD'));" 2>/dev/null; do
    sleep 2
done
echo "Database is up."

php artisan storage:link --force || true
php artisan migrate --force

exec "$@"
