<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OrderValid — Chargeback evidence packets for event organizers</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-white text-slate-900">

    <nav class="flex items-center justify-between px-8 py-5 border-b border-slate-100">
        <span class="font-semibold">OrderValid</span>
        <a href="#apply" class="bg-blue-900 text-white text-sm px-4 py-2 rounded-md">Apply for the pilot</a>
    </nav>

    <header class="text-center px-6 py-20 max-w-3xl mx-auto">
        <p class="text-blue-900 text-xs font-semibold tracking-wide uppercase">Independent pilot · $29</p>
        <h1 class="text-4xl font-bold mt-3 leading-tight">
            Prepare your event chargeback evidence without rebuilding the story by hand.
        </h1>
        <p class="text-slate-500 mt-4">
            For event organizers using Ticket Tailor + Stripe. Turn order and check-in records into an
            organized evidence packet you can review and submit.
        </p>
        <a href="#apply" class="inline-block mt-6 bg-blue-900 text-white px-6 py-3 rounded-md font-medium">
            Apply for the $29 pilot
        </a>
    </header>

    <section class="px-8 py-12 max-w-5xl mx-auto">
        <h2 class="font-semibold mb-6">What you receive</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="font-medium text-sm">Case summary PDF</p>
                <p class="text-slate-500 text-sm mt-1">Order ID, event, timeline and an index of every piece of evidence.</p>
            </div>
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="font-medium text-sm">Attendance evidence PDF</p>
                <p class="text-slate-500 text-sm mt-1">Linked tickets, check-in records and timestamps from Ticket Tailor.</p>
            </div>
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="font-medium text-sm">Draft response text</p>
                <p class="text-slate-500 text-sm mt-1">Factual text ready to paste into the relevant Stripe response fields.</p>
            </div>
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="font-medium text-sm">Missing information list</p>
                <p class="text-slate-500 text-sm mt-1">A clear list of what you still need to provide, shown before export.</p>
            </div>
        </div>
    </section>

    <section class="px-8 py-12 max-w-5xl mx-auto">
        <h2 class="font-semibold mb-6">How it works</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="text-blue-900 font-semibold">1</p>
                <p class="font-medium text-sm mt-1">Tell us about your case</p>
                <p class="text-slate-500 text-sm mt-1">Order details, dispute reason and the response deadline from Stripe.</p>
            </div>
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="text-blue-900 font-semibold">2</p>
                <p class="font-medium text-sm mt-1">We check compatibility</p>
                <p class="text-slate-500 text-sm mt-1">Confirmed before you pay — no surprise if your files don't fit the scope.</p>
            </div>
            <div class="border border-slate-200 rounded-lg p-4">
                <p class="text-blue-900 font-semibold">3</p>
                <p class="font-medium text-sm mt-1">Receive your packet</p>
                <p class="text-slate-500 text-sm mt-1">Delivered within two business days after we accept your files and payment.</p>
            </div>
        </div>
    </section>

    <section class="bg-blue-950 text-white text-center px-8 py-12">
        <p class="text-xl font-semibold">$29 for up to three cases within 30 days</p>
        <p class="text-blue-200 text-sm mt-1">Pay only after we confirm your files are compatible.</p>
        <a href="#apply" class="inline-block mt-5 bg-white text-blue-950 px-6 py-3 rounded-md font-medium">
            Apply for the $29 pilot
        </a>
    </section>

    <section id="apply" class="px-8 py-16 max-w-md mx-auto">
        <h2 class="font-semibold text-xl mb-1">Apply for the pilot</h2>
        <p class="text-slate-500 text-sm mb-6">Tell us a bit about your setup — we'll follow up by email to confirm compatibility before anything is charged.</p>

        @if (session('applied'))
            <div class="bg-green-50 text-green-800 text-sm rounded-md p-3 mb-4">
                Thanks — we got it. We'll follow up by email shortly.
            </div>
        @endif

        @if ($errors->any())
            <div class="bg-red-50 text-red-800 text-sm rounded-md p-3 mb-4">
                {{ $errors->first() }}
            </div>
        @endif

        <form method="POST" action="{{ route('landing.apply') }}" class="space-y-3">
            @csrf
            <input name="name" placeholder="Your name" class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" value="{{ old('name') }}">
            <input name="email" type="email" required placeholder="you@example.com" class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" value="{{ old('email') }}">
            <input name="event_platform" placeholder="Ticketing platform (e.g. Ticket Tailor)" class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" value="{{ old('event_platform') }}">
            <input name="payment_processor" placeholder="Payment processor (e.g. Stripe)" class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" value="{{ old('payment_processor') }}">
            <textarea name="notes" placeholder="Anything else we should know?" rows="3" class="w-full border border-slate-300 rounded-md px-3 py-2 text-sm">{{ old('notes') }}</textarea>
            <button type="submit" class="w-full bg-blue-900 text-white rounded-md py-2 font-medium text-sm">Apply</button>
        </form>
    </section>

    <footer class="text-center text-xs text-slate-400 border-t border-slate-100 py-6">
        Independent service. Not affiliated with Ticket Tailor or Stripe.
    </footer>

</body>
</html>
