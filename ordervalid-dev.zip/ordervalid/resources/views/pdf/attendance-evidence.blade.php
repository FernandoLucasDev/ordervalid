<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    body { font-family: sans-serif; font-size: 12px; color: #111827; }
    h1 { font-size: 18px; margin-bottom: 4px; }
    .muted { color: #6b7280; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    td, th { padding: 6px 8px; border-bottom: 1px solid #e5e7eb; text-align: left; }
</style>
</head>
<body>
    <h1>Attendance Evidence — {{ $case->reference }}</h1>
    <p class="muted">Check-in records pulled from Ticket Tailor for order {{ $case->ticket_tailor_order_id }}</p>

    <table>
        <tr><th>Ticket ID</th><th>Holder</th><th>Checked in at</th></tr>
        @forelse (($order['check_ins'] ?? []) as $checkIn)
            <tr>
                <td>{{ $checkIn['ticket_id'] }}</td>
                <td>{{ $checkIn['holder_name'] }}</td>
                <td>{{ $checkIn['checked_in_at'] }}</td>
            </tr>
        @empty
            <tr><td colspan="3">No check-in records found.</td></tr>
        @endforelse
    </table>
</body>
</html>
