<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    body { font-family: sans-serif; font-size: 12px; color: #111827; }
    h1 { font-size: 18px; margin-bottom: 4px; }
    .muted { color: #6b7280; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    td, th { padding: 6px 8px; border-bottom: 1px solid #e5e7eb; text-align: left; }
</style>
</head>
<body>
    <h1>Case Summary — {{ $case->reference }}</h1>
    <p class="muted">Generated {{ now()->toFormattedDateString() }}</p>

    <table>
        <tr><th>Event</th><td>{{ $case->event_name }}</td></tr>
        <tr><th>Buyer</th><td>{{ $order['buyer_name'] ?? $case->customer_name }} ({{ $order['buyer_email'] ?? $case->customer_email }})</td></tr>
        <tr><th>Ticket Tailor order</th><td>{{ $case->ticket_tailor_order_id }}</td></tr>
        <tr><th>Stripe charge</th><td>{{ $case->stripe_charge_id }}</td></tr>
        <tr><th>Dispute reason</th><td>{{ $case->dispute_reason }}</td></tr>
        <tr><th>Amount</th><td>{{ $case->amount_formatted }}</td></tr>
        <tr><th>Response deadline</th><td>{{ optional($case->response_deadline)->toFormattedDateString() }}</td></tr>
    </table>

    <h2 style="font-size: 14px; margin-top: 24px;">Line items</h2>
    <table>
        <tr><th>Description</th><th>Amount</th></tr>
        @foreach (($order['line_items'] ?? []) as $item)
            <tr><td>{{ $item['description'] }}</td><td>{{ number_format($item['amount'] / 100, 2) }}</td></tr>
        @endforeach
    </table>
</body>
</html>
