# OrderValid — dev environment

Chargeback evidence packets for event organizers using Ticket Tailor + Stripe.
Stack: Laravel 12 + Filament 3 (admin panel), MySQL, Docker.

## Run locally (Docker)

```bash
docker compose up -d --build
```

- App: http://localhost:8080
- Admin panel: http://localhost:8080/admin
  - Login: `fernando@ordervalid.dev` / `ordervalid-dev` (seeded — see below)

The first boot runs migrations automatically (`docker/entrypoint.sh`). To seed the
dev admin user:

```bash
docker compose exec app php artisan db:seed
```

## Stripe / Ticket Tailor keys

Leave `STRIPE_SECRET` and `TICKET_TAILOR_API_KEY` empty in dev — both service
clients (`app/Services/StripeClient.php`, `app/Services/TicketTailorClient.php`)
fall back to realistic mock data so every screen is clickable without real
credentials. Fill them in (via `.env` or the compose `environment:` block) to
pull real orders/charges.

## What's here

- `app/Models`: `CaseModel` (table `cases`), `EvidenceDocument`, `Lead`
- `app/Filament/Resources/CaseResource`: Dashboard (list), New Case (create
  form), Evidence Review (view page) — matches the 4 Figma screens
- `app/Filament/Resources/LeadResource`: every "Apply for the $29 pilot"
  submission from the landing page lands here — this is the validation signal
- `app/Services/EvidencePacketGenerator.php`: pulls the order + charge, decides
  compatibility, generates the PDFs + draft response text
- `resources/views/landing/index.blade.php`: the public landing page (Tailwind
  via CDN, no build step needed)

## Deploying

The same `docker-compose.yml` is what gets deployed to the VPS via Hostinger's
Docker Compose manager, pointed at this repo. `APP_KEY` ships with a dev
placeholder in `docker-compose.yml` — generate a real one
(`php artisan key:generate --show`) and override it via environment variables
before this handles real data.
